
phonegap-plugin-local-notification
------------------------

An implementation of the Web Notifications API for end-user notifications.
