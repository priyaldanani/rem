var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);


var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
       
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}

function checkMedicineTimeup(){
  // Fede In Effect when Page Load..
    // var selectedtime = JSON.parse(localStorage.time);
    // var selectedday = JSON.parse(localStorage.day);
    //console.log(results.rows);
    db.transaction(function (tx) {
        tx.executeSql("SELECT * FROM MEDICINE", [], function (tx, results) {
            var data = results.rows;

            console.log(data.length);
            var date = new Date();
            var hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
            var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
            var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
            
            //Kalpesh: accuracy level till hours and minuts is enough, adding seconds will only work if system is checking exactly at 00 seconds
            time = hours + ":" + minutes;
            //time = hours + ":" + minutes + ":" + seconds;

            //Kalpesh: code is very badly formatted, the curly brackets needs to start and end at correct location to make it easy to read
            //I have made the necesary changes
            for (var i = 0 ; i < data.length; i++) {
                var medicinename = data[i].medicinename;
                var medicinetype = data[i].medicinetype;
                var selectedtime1 = data[i].time1;
                var selectedtime2 = data[i].time2;
                var selectedtime3 = data[i].time3;
                console.log(medicinetype+" "+medicinename+" "+selectedtime1);
                
                if(selectedtime1 == 'BB' ){
                    if("18:10"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken before Breakfast");
                        console.log("match");
                    }
                }

                if(selectedtime1 == 'AB' ){
                    if("10:00"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken after Breakfast");
                        console.log("match");
                    }
                }

                if(selectedtime2 == 'BL' ){
                    if("12:00"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken before lunch");
                        console.log("match");
                    }
                }
                
                if(selectedtime2 == 'AL' ){
                    if("14:00"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken after lunch");
                        console.log("match");
                    }
                }

                if(selectedtime3 == 'BD' ){
                    if("19:13"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken before dinner");
                        console.log("match");
                    }
                }

                if(selectedtime1 == 'AD' ){
                    if("22:00"==time){
                        showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken after dinner");
                        console.log("match");
                    }
                }

                //Kalpesh: This is for testing, comment after tesing is over
                //showNotification("Take Medicine", medicinename + " " + medicinetype, "This medicine needs to be taken before dinner");
            }
                
           console.log("start1");
        }); 
    });
}




//Kalpesh: Parameter is missing, how will function know what to notify ?
//Kalpesh: Adding parameter, and changing function name to that is easy to understand
function showNotification(title, msg, body)
{
    
    if ("Notification" in window) {
        Notification.requestPermission();
        
        if (Notification.permission === 'granted') {
            var notification = new Notification(title, {
                   body: msg
            }); 
        }
    }
    
    //Kalpesh: this is not the code we wrote, we had removed the quotes 
    //and replaced with simple quotes and we also separated the permission code and execution code
// if (“Notification” in window) {
//   Notification.requestPermission(function (permission) {
//     // If the user accepts, let’s create a notification
//     if (permission === ‘granted’) {
//       var notification = new Notification(“My title”, {
//            tag: ‘message1’, 
//            body: “My body” 
//       }); 
//       notification.onshow  = function() { console.log(‘show’); };
//       notification.onclose = function() { console.log(‘close’); };
//       notification.onclick = function() { console.log(‘click’); };
//     }
//   });
}


$(document).ready(function () // Call function when page is ready for load..
{ 
    //alert('notify');
    initDatabase();
    console.log("page start");

    if ("Notification" in window) {
        Notification.requestPermission();
    }

    showNotification("hi", "test", "not used");

    //Kalpesh: Run this code every 30 seconds
    setInterval(checkMedicineTimeup, 30 * 1000);

    console.log("data loaded");
});
