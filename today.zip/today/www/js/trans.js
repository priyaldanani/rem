var selectedMeat=[];
var selectedvegetables=[];
var selectedfruits=[];
var selecteddp=[];
 var db = openDatabase("AddressBook", "1.0", "Address Book", 200000);  // Open SQLite Database
 var selectStatement = "select * from RECIPES where ind1 in (?);"
var dataset; 


function checkpage()
{
                                    //alert("GOing there");
                                    window.location.href="home.html";
}


function getcheckeditems()

{
                // Fetching Meat items in array
                var itemsmeat=document.getElementsByName('meat');
				
                var j =0;
				for(var i=0; i<itemsmeat.length; i++)
                {
					if(itemsmeat[i].checked==true)
                        {
						selectedMeat[j]=itemsmeat[i].value;
                    
                    j++;
                        }
                }
    
					//alert(selectedMeat);
                
    
                
                // Getting vegetables in array
                var itemsveg=document.getElementsByName('vegetables');
				var selectedvegetables=[];
                j =0;
				for(var i=0; i<itemsveg.length; i++)
                {
					if(itemsveg[i].checked==true)
                        {
						  selectedvegetables[j]=itemsveg[i].value;
                            j++;
                        }
                    
                }
    
    	//alert(selectedvegetables);
            
                        
                // Getting Fruits in array
                var itemsfruits=document.getElementsByName('fruits');
				var selectedfruits=[];
                j =0;
				for(var i=0; i<itemsfruits.length; i++)
                {
					if(itemsfruits[i].checked==true)
                        {
						selectedfruits[j]=itemsfruits[i].value;
                    
                    j++;
                        }
                }
              
					//alert(selectedfruits);
    
                // Getting dairy in array
                var itemsdairy=document.getElementsByName('dairyproducts');
				var selecteddp=[];
                j =0;
				for(var i=0; i<itemsdairy.length; i++)
                {
					if(itemsdairy[i].checked==true)
                        {
						selecteddp[j]=itemsdairy[i].value;
                    
                    j++;
                        }
                }
            //alert(selecteddp);
                if( !window.localStorage) alert("Sorry, you're using an ancient browser");
                else {
                    localStorage.vegetables = JSON.stringify(selectedvegetables);
                    localStorage.fruits = JSON.stringify(selectedfruits);
                    localStorage.dp = JSON.stringify(selecteddp);
                    localStorage.meat = JSON.stringify(selectedMeat);
                }           
    
            window.location.href="recipes.html";
    
            //compare();
               
}



/*function compare() // Function For Retrive data from Database Display records as list
 
{
 
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [selectedvegetables], function (tx, result) {
 
            dataset = result.rows;
 
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
 
                var linkeditdelete = '<li>' + item['name'] + ' , ' + item['cuisine'] + '  , ' + item['instructions'] + ' ' + '<a href="#" onclick="loadRecord(' + i + ');">edit</a>' + '    ' +
 
                                            '<a href="#" onclick="deleteRecord(' + item['id'] + ');">delete</a></li>';
 
                $("#results").append(linkeditdelete);
 
            }
 
        });
 
    });
 
}

*/




