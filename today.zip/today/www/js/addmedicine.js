
 
var insertStatement = "INSERT INTO MEDICINE (medicinename, medicinetype, time1, time2, time3) VALUES (?,?,?,?,?)";

var selectStatement = "SELECT * FROM MEDICINE";
 
 var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);  // Open SQLite Database
 
var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            //alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}
 
function createTable()  // Function for Create Table in SQLite.
 
{
    alert('create MEDICINE');
 
   //do nothing;
 
}
 
function insertRecord() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
 
{



// if (“Notification” in window) {
//   Notification.requestPermission(function (permission) {
//     // If the user accepts, let’s create a notification
//     if (permission === ‘granted’) {
//       var notification = new Notification(“My title”, {
//            tag: ‘message1’, 
//            body: “My body” 
//       }); 
//       notification.onshow  = function() { console.log(‘show’); };
//       notification.onclose = function() { console.log(‘close’); };
//       notification.onclick = function() { console.log(‘click’); };
//     }
//   });



// if ("Notification" in window) {
//   Notification.requestPermission(function (permission) {
//     // If the user accepts, create a notification
//     var notification = new Notification("My title", {
//            tag: 'message1', 
//            body: "My body" 
//         }); 
//       notification.onshow  = function() { console.log('show'); };
//       notification.onclose = function() { console.log('close'); };
//       notification.onclick = function() { console.log('click'); };
//   });

//function showNotification(title, msg, body)
//{
    
    // if ("Notification" in window) {
    //     Notification.requestPermission();
        
    //     if (Notification.permission === 'granted') {
    //         var notification = new Notification(title, {
    //                tag: msg  , 
    //                body: body
    //         }); 
    //     }
    // }
       
  //   if ("Notification" in window) {
  // Notification.requestPermission(function (permission) {
  //   // If the user accepts, create a notification
  //   var notification = new Notification("My title", {
  //          tag: 'message1', 
  //          body: "My body" 
  //       }); 
  //     notification.onshow  = function() { console.log('show'); };
  //     notification.onclose = function() { console.log('close'); };
  //     notification.onclick = function() { console.log('click'); };
  // });
  
   //  var nametemp =$('input:text[id=name]').val();
     var nametemp= document.getElementById("medicinename").value;   
    var typeonmp =$("input[name='type']:checked").val();
    // var daytemp =$("input[name='day']:checked").val();
      //var daytemp = document.getElementById("day").value;
       // var datetemp = $('input:text[id=date]').val();
         //var spentontemp = $('input:text[id=spent on]').val();
         //var amounttemp = $('input:text[id=amount]').val();
   // var timetemp = $('input:text[id=details]').val();
     var time1temp =$("input[name='time1']:checked").val();
      var time2temp =$("input[name='time2']:checked").val();
       var time3temp =$("input[name='time3']:checked").val();
    //alert(methodtemp);
    //alert(spentonmp);
    
    
    
    //alert(datetemp);
    //alert(amounttemp);
    
    
        
       db.transaction(function (tx) { tx.executeSql(insertStatement, [nametemp,typeonmp,time1temp,time2temp,time3temp], loadAndReset, onError); });
 
      // alert("inserted");
 
}
 


























function fetch()


{alert('fetch');
   //do nothing
    
}


 function showRecords()
{
    alert("table created or exists");
}

 
function resetForm() // Function for reset form input values.
 
{
 
   alert("not inserted");
   // $("#id").val("");
 
}
 
function loadAndReset() //Function for Load and Reset...
 
{
 
  // alert("inserted");
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}
 

 
$(document).ready(function () // Call function when page is ready for load..
 
{
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    $("#addmedButton").click(insertRecord);  // Register Event Listener when button click.
 //$("#viewButton").click(viewRecord);  // Register Event Listener when button click.
    
    $("#btnReset").click(resetForm);
 
 
});
 







 /*
var insertStatement = "INSERT INTO MEDICINE (medicinename, medicinetype, day, time) VALUES (?,?,?,?)";

var selectStatement = "SELECT * FROM MEDICINE";
 
 var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);  // Open SQLite Database
 
var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            //alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}
 
function createTable()  // Function for Create Table in SQLite.
 
{
    alert('create MEDICINE');
 
   //do nothing;
 
}
 
function insertRecord() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
 
{
if ("Notification" in window) {
  Notification.requestPermission(function (permission) {
    // If the user accepts, create a notification
      notification.onshow  = function() { console.log('show'); };
      notification.onclose = function() { console.log('close'); };
      notification.onclick = function() { console.log('click'); };
  });
}

       if (Notification.permission === 'granted') {
           var notification = new Notification("My title", {
           tag: 'message1', 
           body: "My body" 
        }); 
      }

  
   //  var nametemp =$('input:text[id=name]').val();
     var nametemp= document.getElementById("medicinename").value;   
    var typeonmp =$("input[name='type']:checked").val();
     var daytemp =$("input[name='day']:checked").val();
      //var daytemp = document.getElementById("day").value;
       // var datetemp = $('input:text[id=date]').val();
         //var spentontemp = $('input:text[id=spent on]').val();
         //var amounttemp = $('input:text[id=amount]').val();
   // var timetemp = $('input:text[id=details]').val();
     var timetemp =$("input[name='time']:checked").val();
    //alert(methodtemp);
    //alert(spentonmp);
    
    
    
    //alert(datetemp);
    //alert(amounttemp);
    
    
        
       db.transaction(function (tx) { tx.executeSql(insertStatement, [nametemp,typeonmp,daytemp,timetemp], loadAndReset, onError); });
 
      // alert("inserted");
 
}
 


























function fetch()


{alert('fetch');
   //do nothing
    
}


 function showRecords()
{
    alert("table created or exists");
}

 
function resetForm() // Function for reset form input values.
 
{
 
   alert("not inserted");
   // $("#id").val("");
 
}
 
function loadAndReset() //Function for Load and Reset...
 
{
 
  // alert("inserted");
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}
 

 
$(document).ready(function () // Call function when page is ready for load..
 
{
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    $("#addmedButton").click(insertRecord);  // Register Event Listener when button click.
 //$("#viewButton").click(viewRecord);  // Register Event Listener when button click.
    
    $("#btnReset").click(resetForm);
 
 
});
*/