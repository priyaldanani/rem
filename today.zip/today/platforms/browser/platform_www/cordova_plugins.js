cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-dialogs/www/notification.js",
        "id": "cordova-plugin-dialogs.notification",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/browser/notification.js",
        "id": "cordova-plugin-dialogs.notification_browser",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/phonegap-plugin-local-notification/www/notification.js",
        "id": "phonegap-plugin-local-notification.Notification",
        "pluginId": "phonegap-plugin-local-notification",
        "clobbers": [
            "Notification"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-dialogs": "2.0.2",
    "phonegap-plugin-local-notification": "1.0.1",
    "cordova-plugin-whitelist": "1.3.4"
}
// BOTTOM OF METADATA
});