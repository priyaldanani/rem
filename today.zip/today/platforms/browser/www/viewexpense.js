var db = openDatabase("EXPENSE RECORD", "1.0", "EXPENSE", 200000);


var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}

function viewRecord(){


db.transaction(function (tx) {
tx.executeSql('SELECT * FROM EXPENSE', [], function (tx, results) {
  var len = results.rows.length, i;
  for (i = 0; i < len; i++) {
    alert(results.rows.item(i).text);
  }
});
});

}



function fetch()


{alert('fetch');
   //do nothing
    
}




$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    $("#viewexpButton").click(viewRecord);  // Register Event Listener when button click.
 
 
 
});
