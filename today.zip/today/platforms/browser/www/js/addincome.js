
 
var insertStatement2 = "INSERT INTO INCOME (method, date, recfrom, amount, details) VALUES (?,?,?,?,?)";

var selectStatement2 = "SELECT * FROM INCOME";

 var db2 = openDatabase("EXPENSE RECORD", "1.0", "INCOME", 200000);  // Open SQLite Database
 
var dataset22;    
 
var DataType2;
 
 function initDatabase2()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch2();  // If supported then call Function for create table in SQLite
            alert('init data 2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}
 
function createTable2()  // Function for Create Table in SQLite.
 
{
 alert('create 2');
   //do nothing;
 
}
 
function insertRecord2() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
 
{
    alert("inside");
 
     var methodtemp2 =$("input[name='method']:checked").val();
        
    var recfromtemp2 =$("input[name='recv from']:checked").val();
      var datetemp2 = document.getElementById("date").value;
       // var datetemp = $('input:text[id=date]').val();
         var spentontemp2 = $('input:text[id=recv from]').val();
         var amounttemp2 = $('input:text[id=amount]').val();
    var detailstemp2 = $('input:text[id=details]').val();
    
    //alert(methodtemp);
    //alert(spentonmp);
    
    
    
    //alert(datetemp);
    //alert(amounttemp);
    
    
        
       db2.transaction(function (tx) { tx.executeSql(insertStatement2, [methodtemp2,datetemp2,recfromtemp2,amounttemp2,detailstemp2], loadAndReset2, onError2); });
 
       alert("inserted");
 
}
 
function fetch2()


{alert('fetch2');
   //do nothing
    
}


 function showRecords2()
{
    alert("table created or exists");
}

 
function resetForm2() // Function for reset form input values.
 
{
 
   alert("not inserted");
   // $("#id").val("");
 
}
 
function loadAndReset2() //Function for Load and Reset...
 
{
 
   alert("inserted");
}
 
function onError2(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}
 

 
$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase2();
 
    $("#addincButton").click(insertRecord2);  // Register Event Listener when button click.
 
    
    $("#btnReset").click(resetForm2);
 
 
});
 