var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);


var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}

function viewRecord(){
 $("body").fadeIn(2000); // Fede In Effect when Page Load..
    // var selectedtime = JSON.parse(localStorage.time);
    // var selectedday = JSON.parse(localStorage.day);
    console.log(results.rows);
    db.transaction(function (tx) {
        tx.executeSql("SELECT * FROM MEDICINE", [], function (tx, results) {
            var data = results.rows;

            console.log(data);
            var date = new Date();
            var hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
            var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
            var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
            time = hours + ":" + minutes + ":" + seconds;

            for (var i = data.length - 1; i >= 0; i--) {
                var medicinename = data[i].medicinename;
                var medicinetype = data[i].medicinetype;
                var selectedtime1 = data[i].time1;
                var selectedtime2 = data[i].time2;
                var selectedtime3 = data[i].time3;
                console.log(medicinetype+" "+medicinename+" "+selectedtime1);
                 if(selectedtime1 == 'BB' ){
                    if("08:00:00"==time){
                        notify1(data[i]);
                        console.log("match");
                }

            }
                    if(selectedtime1 == 'AB' ){
                        if("10:00:00"==time){
                            notify1(data[i]);
                        console.log("match");

                    }
                }

                    if(selectedtime2 == 'BL' ){
                    if("12:00:00"==time){
                        notify1(data[i]);
                        console.log("match");
                }
            }
                if(selectedtime2 == 'AL' ){
                    if("14:00:00"==time){
                        notify1(data[i]);
                        console.log("match");
                }
            }

                    if(selectedtime3 == 'BD' ){
                    if("19:00:00"==time){
                        notify1(data[i]);
                        console.log("match");



                    }
                }

                if(selectedtime1 == 'AD' ){
                    if("22:00:00"==time){
                        notify1(data[i]);
                        console.log("match");
                }
            }
        }
                
               console.log("start1");
        }); 
    });
}


function fetch()


{alert('fetch');
   //do nothing
    
}

function notify1(data[i])
{








// if (“Notification” in window) {
//   Notification.requestPermission(function (permission) {
//     // If the user accepts, let’s create a notification
//     if (permission === ‘granted’) {
//       var notification = new Notification(“My title”, {
//            tag: ‘message1’, 
//            body: “My body” 
//       }); 
//       notification.onshow  = function() { console.log(‘show’); };
//       notification.onclose = function() { console.log(‘close’); };
//       notification.onclick = function() { console.log(‘click’); };
//     }
//   });
}


    if ("Notification" in window) {
  Notification.requestPermission(function (permission) {
    // If the user accepts, create a notification
    var notification = new Notification("My title", {
           tag: 'message1', 
           body: "My body" 
        }); 
      notification.onshow  = function() { console.log('show'); };
      notification.onclose = function() { console.log('close'); };
      notification.onclick = function() { console.log('click'); };
  });
}


$(document).ready(function () // Call function when page is ready for load..
{

 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
    console.log("page start");

    viewRecord();
     //setInterval(function(){ viewRecord(); }, 3000);


    console.log("data loaded");

 
    
 
 
 
});
