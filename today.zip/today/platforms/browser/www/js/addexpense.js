
 
var insertStatement = "INSERT INTO EXPENSE (paymentmethod, date, spenton, amount, details) VALUES (?,?,?,?,?)";

var selectStatement = "SELECT * FROM EXPENSE";
 
 var db = openDatabase("EXPENSE RECORD", "1.0", "EXPENSE", 200000);  // Open SQLite Database
 
var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}
 
function createTable()  // Function for Create Table in SQLite.
 
{
    alert('create expense');
 
   //do nothing;
 
}
 
function insertRecord() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
 
{
    alert("inside");
 
     var methodtemp =$("input[name='method']:checked").val();
        
    var spentonmp =$("input[name='spent on']:checked").val();
      var datetemp = document.getElementById("date").value;
       // var datetemp = $('input:text[id=date]').val();
         var spentontemp = $('input:text[id=spent on]').val();
         var amounttemp = $('input:text[id=amount]').val();
    var detailstemp = $('input:text[id=details]').val();
    
    //alert(methodtemp);
    //alert(spentonmp);
    
    
    
    //alert(datetemp);
    //alert(amounttemp);
    
    
        
       db.transaction(function (tx) { tx.executeSql(insertStatement, [methodtemp,datetemp,spentonmp,amounttemp,detailstemp], loadAndReset, onError); });
 
       alert("inserted");
 
}
 
function fetch()


{alert('fetch');
   //do nothing
    
}


 function showRecords()
{
    alert("table created or exists");
}

 
function resetForm() // Function for reset form input values.
 
{
 
   alert("not inserted");
   // $("#id").val("");
 
}
 
function loadAndReset() //Function for Load and Reset...
 
{
 
   alert("inserted");
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}
 

 
$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    $("#addexpButton").click(insertRecord);  // Register Event Listener when button click.
 
    
    $("#btnReset").click(resetForm);
 
 
});
 