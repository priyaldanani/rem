var selectedItems = [];
var item;
var dataset;

var selectStatement = "SELECT * FROM RECIPES; ";
/*
var selectStatement = "select * from RECIPES where ind1 in [" + selectedItems + " ] OR ind2 in [ " + selectedItems + " ] OR ind2 in [ " + selectedItems + " ] OR ind3 in [ " + selectedItems + " ] OR ind4 in [ " + selectedItems + " ] OR ind5 in [ " + selectedItems + " ] OR ind6 in [ " + selectedItems + " ] OR ind7 in [ " + selectedItems + " ] OR ind8 in [ " + selectedItems + " ] OR ind9 in [ " + selectedItems + " ] OR ind10 in [ " + selectedItems + "];"; 

*/
var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);
var dataset; 
$(document).ready(function () // Call f unction when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
    selectedcuisine = JSON.parse(localStorage.nonvegcuisine);
    //alert(selectedcuisine);
   
    
    initDatabase();
    
});


//var selectStatement = "select * form RECIPES where ind1 in [" + selectedItems + "] OR ind2 in [" + selectedItems + "];"; 


function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            //alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
            
            compare();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}



function compare() // Function For Retrive data from Database Display records as list
 
{
    var tableinit = '<table border=1>';
    $("#results").append(tableinit);
    
    //alert("inside compare");
    
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [], function (tx, result) {
 
            dataset = result.rows;
           var flag=0;
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
              for(var j=0 ; j<=selectedcuisine.length ; j++ )
                            {
               
                                if(item['cuisine'] == selectedcuisine[j] && item['vnv']=="nonveg")
                                {


                                        $("#results").append('<ol>');
                                        /*var linkeditdelete = '<li>' + item['name'] + ' | ' + item['cuisine'] + ' <a href="#" onclick="deleteRecord(' + item['rec_id'] + ');">view recipe</a></li>';
*/

                                        var linkeditdelete = '<tr> <th>' + item['name'] + '</th>  <td> &nbsp;&nbsp;' + item['cuisine'] + '</td> <td>&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="details(' + item['rec_id'] + ');">View Recipe</a></td></tr>';

                                         //$("#results").append(tableinit);
                                        $("#results").append(linkeditdelete);
                            
                        }
                            }
                
                
                
                
            }
            
             $("#results").append('</ol>');
 
        });
 
    });
 
}


function details(rec_id) // Get id of record . Function Call when Delete Button Click..
 
{
 
        var rid = rec_id;
        //alert("storing id" + rid);

        localStorage.rec_id = JSON.stringify(rid);
        window.location.href="details.html";
    
 
}

