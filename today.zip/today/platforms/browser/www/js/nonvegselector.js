

var selectStatement = "SELECT * FROM cuisine";



var selectedcuisine=[];
 //var db = openDatabase("AddressBook", "1.0", "Address Book", 200000);  // Open SQLite Database
var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);
 
var dataset; 




$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
 
    initDatabase();
    
    
});





function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
 
            fetch();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}







function fetch()


{
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="checkbox" name="cuisine" value='+item['cuisinename']+ ' class="regular-checkbox" /> '+ item['cuisinename'] +'<br/>';
             
                 $("#results").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
    
}





function checkpage()
{
                                    //alert("GOing there");
                                    window.location.href="home.html";
}


function getcheckeditems()

{
                // Fetching Meat items in array
                var itemscuisine=document.getElementsByName('cuisine');
				
                var j =0;
				for(var i=0; i<itemscuisine.length; i++)
                {
					if(itemscuisine[i].checked==true)
                        {
						selectedcuisine[j]=itemscuisine[i].value;
                    
                    j++;
                        }
                }
    
			
            //alert(selecteddp);
                if( !window.localStorage) alert("Sorry, you're using an ancient browser");
                else {
                    localStorage.nonvegcuisine = JSON.stringify(selectedcuisine);
                    
                }           
    
            window.location.href="nonvegonly.html";
    
            //compare();
               
}



/*function compare() // Function For Retrive data from Database Display records as list
 
{
 
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [selectedvegetables], function (tx, result) {
 
            dataset = result.rows;
 
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
 
                var linkeditdelete = '<li>' + item['name'] + ' , ' + item['cuisine'] + '  , ' + item['instructions'] + ' ' + '<a href="#" onclick="loadRecord(' + i + ');">edit</a>' + '    ' +
 
                                            '<a href="#" onclick="deleteRecord(' + item['id'] + ');">delete</a></li>';
 
                $("#results").append(linkeditdelete);
 
            }
 
        });
 
    });
 
}

*/




