
 
var insertStatement = "INSERT INTO RECIPES (name, cuisine, ind1, ind2, ind3, ind4, ind5, ind6, ind7, ind8, ind9, ind10, instructions) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
var selectStatement = "SELECT * FROM cuisine";
 
 var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);  // Open SQLite Database
 
var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}
 
function createTable()  // Function for Create Table in SQLite.
 
{
 
   //do nothing;
 
}
 
function insertRecord() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
 
{
    alert("inside");
 
        var nametemp = $('input:text[id=name]').val();
        
    
        var cuisinetemp =$("input[name='cuisine']:checked").val();
        var ind1temp = $('input:text[id=ind1]').val();
         var ind2temp = $('input:text[id=ind2]').val();
         var ind3temp = $('input:text[id=ind3]').val();
         var ind4temp = $('input:text[id=ind4]').val();
         var ind5temp = $('input:text[id=ind5]').val();
         var ind6temp = $('input:text[id=ind6]').val();
         var ind7temp = $('input:text[id=ind7]').val();
         var ind8temp = $('input:text[id=ind8]').val();
         var ind9temp = $('input:text[id=ind9').val();
         var ind10temp = $('input:text[id=ind10]').val();   
         var instructionstemp = $('input:text[id=instructions]').val();
        
    
        db.transaction(function (tx) { tx.executeSql(insertStatement, [nametemp, cuisinetemp, ind1temp, ind2temp, ind3temp, ind4temp, ind5temp, ind6temp, ind7temp, ind8temp, ind9temp, ind10temp, instructionstemp], loadAndReset, onError); });
 
        //tx.executeSql(SQL Query Statement,[ Parameters ] , Sucess Result Handler Function, Error Result Handler Function );
 
}
 
function fetch()


{
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="radio" name="cuisine" value='+item['cuisinename']+ ' class="regular-checkbox" /> '+ item['cuisinename'] +'<br/>';
             
                 $("#results").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
    
}


 function showRecords()
{
    alert("table created or exists");
}

 
function resetForm() // Function for reset form input values.
 
{
 
   alert("not inserted");
   // $("#id").val("");
 
}
 
function loadAndReset() //Function for Load and Reset...
 
{
 
   alert("inserted");
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}
 

 
$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    $("#submitButton").click(insertRecord);  // Register Event Listener when button click.
 
    
    $("#btnReset").click(resetForm);
 
 
});
 