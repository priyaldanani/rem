var createStatement = "CREATE TABLE IF NOT EXISTS MEDICINE (med_id INTEGER PRIMARY KEY AUTOINCREMENT, medicinename TEXT, medicinetype TEXT, time1 TEXT, time2 TEXT, time3 TEXT)";

var insertStatement = "INSERT INTO MEDICINE (medicinename, medicinetype, time1, time2, time3) VALUES (?,?,?,?,?)";
var dropStatement = "DROP TABLE MEDICINE";

var selectAllStatement = "SELECT * FROM MEDICINE";










var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);
var dataset; 
var dataset1,dataset2,dataset3,dataset4,dataset5; 

function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            alert("createing");
            
            createTable();  // If supported then call Function for create table in SQLite
           // fetchrecord();
            alert('initDatabase');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}



































function createTable()  // Function for Create Table in SQLite.
 
{
    
    
    db.transaction(function (tx) { tx.executeSql(createStatement, [],showRecords, onError); });
    alert("created");
    
    checkRecords();

   

    
}























/*
function fetchrecord()
{
    var totalexp=0;
   
    
    $("#results").html('')
    
     var tableinit = '<table border=0> ';
    $("#results").append(tableinit);
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) 
            {
 
                item = dataset.item(i);
                
                totalexp = totalexp + item['amount'];
           
              
               
           
                var tableend ='</table>'  
                
                var linkeditdelete = '<tr><td> '+ totalexp +'</td> </tr> ';
                
                
                        
            }
              $("#results").append(linkeditdelete);
                $("#results").append(tableend);
            
            
        });
 
    });
}







*/

















/*

function checkRecords() // Function For Retrive data from Database Display records as list
 
{
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement, [], function (tx, result) 
                      {
            
            dataset = result.rows;
 
                if(dataset.length==0)
                {
                    insertRecord();
                }
            else
            {
               
            }
 
    });
        });
    alert('checkRecords');

}








*/







                   

function dropFunction()
{
    db.transaction(function (tx) { tx.executeSql(dropStatement, [], showRecords, onError); });   
    alert("tables dropped");
}

















//function insertRecord()
//{
    
  //  db.transaction(function (tx) { tx.executeSql(insertStatement,["cash", '2019-09-18', "food" , 200], loadAndReset, onError); });
    //db.transaction(function (tx) { tx.executeSql(insertStatement,["cash", '2019-04-17', "food" , 500], loadAndReset, onError); });
     //alert("insERTED record");
    

    
//}























function loadAndReset() //Function for Load and Reset...
 
{
 
    
 
    showRecords()
 alert('loadandrequest');
}
 




function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}




function showRecords()
{
     
}


















function addFunction()
{
    window.location.href="addmedicine.html";
}


function viewFunction()
{
    window.location.href="viewmedicine.html";
}





$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
  
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 
    
     $("#addmedButton").click(addFunction);
 $("#dropButton").click(dropFunction);
 $("#notifyButton").click(viewFunction);

 alert('ready');
});






















