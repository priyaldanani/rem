var selectedid;
var item;
var dataset;

var selectStatement = "SELECT * FROM RECIPES where rec_id = ? ";

var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);
var dataset; 
$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
   
    selectedid = JSON.parse(localStorage.rec_id);
    
    initDatabase();
    
});


//var selectStatement = "select * form RECIPES where ind1 in [" + selectedItems + "] OR ind2 in [" + selectedItems + "];"; 


function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            //alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
            
            compare();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}









function compare() // Function For Retrive data from Database Display records as list
 
{
    var tableinit = '<table border=1>';
    $("#results").append(tableinit);
    
    //alert("inside compare");
    
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [selectedid], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
              
                           
                                       
                
               var linkeditdelete = '<div><h2> '+ item['name'] +'</h2> </div> <br> <div> <h3> Ingredients </h3><ol> ';
               
               //<li>' + item['ind1'] + ' </li> <li>' + item['ind2'] + ' </li> <li> ' + item['ind1'] + ' </li> <li>' + item['ind3'] + ' </li> <li> ' + item['ind4'] + ' </li> <li>' + item['ind2'] + ' </li>   </ol>'  ;
                
                
                for(var i =1;i<=10; i++)
                    {
                        if(item['ind'+i]!="")
                        linkeditdelete = linkeditdelete + '<li> ' + item['ind'+i] + '</li>' 
                    }
                
                
                
                linkeditdelete = linkeditdelete  + '</ol> <h3>   Instructions </h3>  <br> ' + item['instructions'];
                
                 $("#results").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
 
}





