var db = openDatabase("MEDICINE RECORD", "1.0", "MEDICINE", 200000);


var dataset;    
 
var DataType;
 
 function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else {
 
            fetch();  // If supported then call Function for create table in SQLite
            alert('init2');
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {
 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}

function viewRecord(){


db.transaction(function (tx) {
tx.executeSql("SELECT * FROM MEDICINE", [], function (tx, results) {
    console.log(results.rows);

var tableinit = '<table border=1><tr><th>name</th><th>type</th><th>day</th><th>time</th></tr>';
            var dataset = results.rows;
            for (var i = 0, item = null; i < dataset.length; i++) 
            {
 
                item = dataset.item(i);
                tableinit = tableinit + '<tr><th>'+item['medicinename']+'</th><th>'+item['medicinetype']+'</th><th>'+item['day']+'</th><th>'+item['time']+'</th></tr>';

    
           
            
  }
  tableinit= tableinit+'</table>';
  $("#results").append(tableinit);
});
});

}



function fetch()


{alert('fetch');
   //do nothing
    
}




$(document).ready(function () // Call function when page is ready for load..
{

 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
    console.log("page start");

    viewRecord();

    console.log("data loaded");

 
    // $("#viewexpButton").click(viewRecord);  // Register Event Listener when button click.
 
 
 
});
