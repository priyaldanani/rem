var createvegetableStatement = "CREATE TABLE IF NOT EXISTS vegetables (v_id INTEGER PRIMARY KEY AUTOINCREMENT, vegetablename TEXT)";

var insertvegetableStatement = "INSERT INTO vegetables (vegetablename) VALUES (?)";
var dropvegetablevegetableStatement = "DROP TABLE vegetables";

var selectAllvegetableStatement = "SELECT * FROM vegetables";


var createfruitStatement = "CREATE TABLE IF NOT EXISTS fruits (f_id INTEGER PRIMARY KEY AUTOINCREMENT, fruitname TEXT)";

var insertfruitStatement = "INSERT INTO fruits (fruitname) VALUES (?)";
var dropfruittableStatement = "DROP TABLE fruits";

var selectAllfruitStatement = "SELECT * FROM fruits";




var createdpStatement = "CREATE TABLE IF NOT EXISTS dps (d_id INTEGER PRIMARY KEY AUTOINCREMENT, dpname TEXT)";

var insertdpStatement = "INSERT INTO dps (dpname) VALUES (?)";
var dropdpdpStatement = "DROP TABLE dps";

var selectAlldpStatement = "SELECT * FROM dps";



var createmeatStatement = "CREATE TABLE IF NOT EXISTS meat (m_id INTEGER PRIMARY KEY AUTOINCREMENT, meatname TEXT)";

var insertmeatStatement = "INSERT INTO meat (meatname) VALUES (?)";
var dropmeatmeatStatement = "DROP TABLE meat";

var selectAllmeatStatement = "SELECT * FROM meat";



var selectedMeat=[];
var selectedvegetables=[];
var selectedfruits=[];
var selecteddp=[];
 



var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);
var dataset1,dataset2,dataset3,dataset4; 







$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
      
    $("#dropAllTabes").click(dropall);
    $("#createTables").click(initDatabase);
    initDatabase();
    
    
});





function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
 
            createTable();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}




function dropall()
{
    db.transaction(function (tx) { tx.executeSql(dropvegetablevegetableStatement, [], showRecords, onError); }); 
    db.transaction(function (tx) { tx.executeSql(dropfruittableStatement, [], showRecords, onError); });   
    
    db.transaction(function (tx) { tx.executeSql(dropdpdpStatement, [], showRecords, onError); });   
   
    db.transaction(function (tx) { tx.executeSql(dropmeatmeatStatement, [], showRecords, onError); });   
   
    alert("tables dropped");
}

function createTable()  // Function for Create Table in SQLite.
 
{
    
    
    db.transaction(function (tx) { tx.executeSql(createvegetableStatement, [],showRecords, onError); });
    db.transaction(function (tx) { tx.executeSql(createfruitStatement, [],showRecords, onError); });
    db.transaction(function (tx) { tx.executeSql(createdpStatement, [],showRecords, onError); });
    db.transaction(function (tx) { tx.executeSql(createmeatStatement, [],showRecords, onError); });
    
    checkRecords();
    
 
    
}






function checkRecords() // Function For Retrive data from Database Display records as list
 
{
 
  
    //vegetables
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllvegetableStatement, [], function (tx, result) 
                      {
 
            dataset1 = result.rows;
 
                if(dataset1.length==0)
                {
                    insertvegRecord();
                }
            else
            {
               
            }
 
    });
        });
    
    
    
    //fruits
     db.transaction(function (tx) {
 
        tx.executeSql(selectAllfruitStatement, [], function (tx, result) 
                      {
 
            dataset2 = result.rows;
 
                if(dataset2.length==0)
                {
                    insertfruitRecord();
                }
            else
            {
               
            }
 
    });
        });
    
    
    //dp
     db.transaction(function (tx) {
 
        tx.executeSql(selectAlldpStatement, [], function (tx, result) 
                      {
 
            dataset3 = result.rows;
 
                if(dataset3.length==0)
                {
                    insertdpRecord();
                }
            else
            {
               
            }
 
    });
        });
    
    
    //meat
     db.transaction(function (tx) {
 
        tx.executeSql(selectAllmeatStatement, [], function (tx, result) 
                      {
 
            dataset4 = result.rows;
 
                if(dataset4.length==0)
                {
                    insertmeatRecord();
                }
            else
            {
               
            }
 
    });
        });
    
    
    
     compare();
 
}
                   






function insertfruitRecord()
{
    	
	db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["apple"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["mango"], loadAndReset, onError); });
   db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["banana"], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["orange"], loadAndReset, onError); });
	db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["grapes"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["pineapple"], loadAndReset, onError); });
   db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["kiwi"], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertfruitStatement,["papaya"], loadAndReset, onError); });
	   
}


function insertdpRecord()
{
    	
	db.transaction(function (tx) { tx.executeSql(insertdpStatement,["milk"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertdpStatement,["paneer"], loadAndReset, onError); });
   db.transaction(function (tx) { tx.executeSql(insertdpStatement,["cream"], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertdpStatement,["curd"], loadAndReset, onError); });
	db.transaction(function (tx) { tx.executeSql(insertdpStatement,["butter"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertdpStatement,["egg"], loadAndReset, onError); });
     
}



function insertmeatRecord()
{
     db.transaction(function (tx) { tx.executeSql(insertmeatStatement,["fish"], loadAndReset, onError); });
	db.transaction(function (tx) { tx.executeSql(insertmeatStatement,["chicken"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertmeatStatement,["mutton"], loadAndReset, onError); });
  
}



function insertvegRecord()
{
    
   db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["tomato"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["potato"], loadAndReset, onError); });
   db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["capsicum"], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["cabbage"], loadAndReset, onError); });
	db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["onion"], loadAndReset, onError); });
  db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["spinach"], loadAndReset, onError); });
   db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["raddish"], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertvegetableStatement,["cauliflower"], loadAndReset, onError); });
	

   
}



function loadAndReset() //Function for Load and Reset...
 
{
 
    
 
    showRecords()
 
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}


function showRecords()
{
     
}



function compare() // Function For Retrive data from Database Display records as list
 
{
   
   
    
    $("#results1").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllvegetableStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="checkbox" name="vegetables" value='+item['vegetablename']+ ' class="regular-checkbox" /> '+ item['vegetablename'] +'<br/>';
             
                 $("#results1").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
    
    
    
     
    $("#results2").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllfruitStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="checkbox" name="fruits" value='+item['fruitname']+ ' class="regular-checkbox" /> '+ item['fruitname'] +'<br/>';
             
                 $("#results2").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
 
 
     $("#results3").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAlldpStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="checkbox" name="dairyproducts" value='+item['dpname']+ ' class="regular-checkbox" /> '+ item['dpname'] +'<br/>';
             
                 $("#results3").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
 
    
    $("#results4").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllmeatStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
               var linkeditdelete = ' <input type="checkbox" name="meat" value='+item['meatname']+ ' class="regular-checkbox" /> '+ item['meatname'] +'<br/>';
             
                 $("#results4").append(linkeditdelete);
                
                
                
                        
            }
        });
 
    });
 
    
    
 
}





function getcheckeditems()

{
                // Fetching Meat items in array
                var itemsmeat=document.getElementsByName('meat');
				
                var j =0;
				for(var i=0; i<itemsmeat.length; i++)
                {
					if(itemsmeat[i].checked==true)
                        {
						selectedMeat[j]=itemsmeat[i].value;
                    
                    j++;
                        }
                }
    
					//alert(selectedMeat);
                
    
                
                // Getting vegetables in array
                var itemsveg=document.getElementsByName('vegetables');
				var selectedvegetables=[];
                j =0;
				for(var i=0; i<itemsveg.length; i++)
                {
					if(itemsveg[i].checked==true)
                        {
						  selectedvegetables[j]=itemsveg[i].value;
                            j++;
                        }
                    
                }
    
    	//alert(selectedvegetables);
            
                        
                // Getting Fruits in array
                var itemsfruits=document.getElementsByName('fruits');
				var selectedfruits=[];
                j =0;
				for(var i=0; i<itemsfruits.length; i++)
                {
					if(itemsfruits[i].checked==true)
                        {
						selectedfruits[j]=itemsfruits[i].value;
                    
                    j++;
                        }
                }
              
					//alert(selectedfruits);
    
                // Getting dairy in array
                var itemsdairy=document.getElementsByName('dairyproducts');
				var selecteddp=[];
                j =0;
				for(var i=0; i<itemsdairy.length; i++)
                {
					if(itemsdairy[i].checked==true)
                        {
						selecteddp[j]=itemsdairy[i].value;
                    
                    j++;
                        }
                }
            //alert(selecteddp);
                if( !window.localStorage) alert("Sorry, you're using an ancient browser");
                else {
                    localStorage.vegetables = JSON.stringify(selectedvegetables);
                    localStorage.fruits = JSON.stringify(selectedfruits);
                    localStorage.dp = JSON.stringify(selecteddp);
                    localStorage.meat = JSON.stringify(selectedMeat);
                }           
    
            window.location.href="recipes.html";
    
            //compare();
               
}




