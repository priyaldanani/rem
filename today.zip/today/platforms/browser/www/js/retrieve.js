var selectedItems = [];
var item;
var dataset;

var selectStatement = "SELECT * FROM RECIPES; ";
/*
var selectStatement = "select * from RECIPES where ind1 in [" + selectedItems + " ] OR ind2 in [ " + selectedItems + " ] OR ind2 in [ " + selectedItems + " ] OR ind3 in [ " + selectedItems + " ] OR ind4 in [ " + selectedItems + " ] OR ind5 in [ " + selectedItems + " ] OR ind6 in [ " + selectedItems + " ] OR ind7 in [ " + selectedItems + " ] OR ind8 in [ " + selectedItems + " ] OR ind9 in [ " + selectedItems + " ] OR ind10 in [ " + selectedItems + "];"; 

*/
var db = openDatabase("RECIPES", "1.0", "Recipe Book", 200000);
var dataset; 
$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
    selectedvegetables = JSON.parse(localStorage.vegetables);
    selectedfruits = JSON.parse(localStorage.fruits);
    selecteddp = JSON.parse(localStorage.dp);
    selectedmeat = JSON.parse(localStorage.meat);
   
    initDatabase();
    
});


//var selectStatement = "select * form RECIPES where ind1 in [" + selectedItems + "] OR ind2 in [" + selectedItems + "];"; 


function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            //alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
            
            compare();  // If supported then call Function for create table in SQLite
 
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}



function compare() // Function For Retrive data from Database Display records as list
 
{
    var tableinit = '<table border=1>';
    $("#results").append(tableinit);
    
    //alert("inside compare");
    
    $("#results").html('')
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectStatement, [], function (tx, result) {
 
            var shown =[];
            var flag2=0;
            dataset = result.rows;
           var flag=0;
            for (var i = 0, item = null; i < dataset.length; i++) {
 
                item = dataset.item(i);
                
              
                //for vegetables
                for(var j=1 ; j<=10; j++)
                    {
                        for(var k = 0; k<selectedvegetables.length; k++)
                            {
                                if(item['ind'+j] == selectedvegetables[k])
                                {

                                        flag=1;
                                        
                                }
                            }
                    }
                
                    if(flag == 1 )
                        {
                            for(var x=0;x<shown.length;x++)
                                {
                                    if(item['rec_id']==shown[x])
                                        {
                                            flag2=1;
                                        }
                                }
                            if(flag2==0)
                                {
                                        $("#results").append('<ol>');
                                        /*var linkeditdelete = '<li>' + item['name'] + ' | ' + item['cuisine'] + ' <a href="#" onclick="deleteRecord(' + item['rec_id'] + ');">view recipe</a></li>';
*/

                                        var linkeditdelete = '<tr>  <th>' + item['name'] + '</th>  <td> &nbsp;&nbsp;' + item['cuisine'] + '</td> <td>&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="details(' + item['rec_id'] + ');">View Recipe</a></td></tr>';

                                         //$("#results").append(tableinit);
                                        $("#results").append(linkeditdelete);
                                    
                                        shown.push(item['rec_id']);
                                        flag2=0;
                                }
                            flag=0;
                                
                        }
                
        
                
                 //for dp
                for(var j=1 ; j<=10; j++)
                    {
                        for(var k = 0; k<selecteddp.length; k++)
                            {
                                if(item['ind'+j] == selecteddp[k])
                                {

                                        flag=1;
                                        
                                }
                            }
                    }
                
                    if(flag == 1 )
                        {
                            for(var x=0;x<shown.length;x++)
                                {
                                    if(item['rec_id']==shown[x])
                                        {
                                            flag2=1;
                                        }
                                }
                            if(flag2==0)
                                {
                                        $("#results").append('<ol>');
                                        /*var linkeditdelete = '<li>' + item['name'] + ' | ' + item['cuisine'] + ' <a href="#" onclick="deleteRecord(' + item['rec_id'] + ');">view recipe</a></li>';
*/

                                        var linkeditdelete = '<tr>  <th>' + item['name'] + '</th>  <td> &nbsp;&nbsp;' + item['cuisine'] + '</td> <td>&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="details(' + item['rec_id'] + ');">View Recipe</a></td></tr>';

                                         //$("#results").append(tableinit);
                                        $("#results").append(linkeditdelete);
                                    
                                        shown.push(item['rec_id']);
                                        flag2=0;
                                }
                            flag=0;
                                
                        }
                
                
                
                
                
                
                 //for fruits
                for(var j=1 ; j<=10; j++)
                    {
                        for(var k = 0; k<selectedfruits.length; k++)
                            {
                                if(item['ind'+j] == selectedfruits[k])
                                {

                                        flag=1;
                                        
                                }
                            }
                    }
                
                    if(flag == 1 )
                        {
                            for(var x=0;x<shown.length;x++)
                                {
                                    if(item['rec_id']==shown[x])
                                        {
                                            flag2=1;
                                        }
                                }
                            if(flag2==0)
                                {
                                        $("#results").append('<ol>');
                                        /*var linkeditdelete = '<li>' + item['name'] + ' | ' + item['cuisine'] + ' <a href="#" onclick="deleteRecord(' + item['rec_id'] + ');">view recipe</a></li>';
*/

                                        var linkeditdelete = '<tr>  <th>' + item['name'] + '</th>  <td> &nbsp;&nbsp;' + item['cuisine'] + '</td> <td>&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="details(' + item['rec_id'] + ');">View Recipe</a></td></tr>';

                                         //$("#results").append(tableinit);
                                        $("#results").append(linkeditdelete);
                                    
                                        shown.push(item['rec_id']);
                                        flag2=0;
                                }
                            flag=0;
                                
                        }
                
                
                
                
                
                
                 //for meat
                for(var j=1 ; j<=10; j++)
                    {
                        for(var k = 0; k<selectedmeat.length; k++)
                            {
                                if(item['ind'+j] == selectedmeat[k])
                                {

                                        flag=1;
                                        
                                }
                            }
                    }
                
                    if(flag == 1 )
                        {
                            for(var x=0;x<shown.length;x++)
                                {
                                    if(item['rec_id']==shown[x])
                                        {
                                            flag2=1;
                                        }
                                }
                            if(flag2==0)
                                {
                                        $("#results").append('<ol>');
                                        /*var linkeditdelete = '<li>' + item['name'] + ' | ' + item['cuisine'] + ' <a href="#" onclick="deleteRecord(' + item['rec_id'] + ');">view recipe</a></li>';
*/

                                        var linkeditdelete = '<tr>  <th>' + item['name'] + '</th>  <td> &nbsp;&nbsp;' + item['cuisine'] + '</td> <td>&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="details(' + item['rec_id'] + ');">View Recipe</a></td></tr>';

                                         //$("#results").append(tableinit);
                                        $("#results").append(linkeditdelete);
                                    
                                        shown.push(item['rec_id']);
                                        flag2=0;
                                }
                            flag=0;
                                
                        }
                
                
            
            }
            
                   
             $("#results").append('</ol>');
 
        });
 
    });
 
}


function details(rec_id) // Get id of record . Function Call when Delete Button Click..
 
{
 
        var rid = rec_id;
        //alert("storing id" + rid);

        localStorage.rec_id = JSON.stringify(rid);
        window.location.href="details.html";
    
 
}

