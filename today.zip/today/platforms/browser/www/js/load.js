var createStatement = "CREATE TABLE IF NOT EXISTS EXPENSE (exp_id INTEGER PRIMARY KEY AUTOINCREMENT, paymentmethod TEXT, date DATE, spenton TEXT, amount INTEGER, details TEXT)";

var insertStatement = "INSERT INTO EXPENSE (paymentmethod, date, spenton, amount) VALUES (?,?,?,?)";
var dropStatement = "DROP TABLE EXPENSE";

var selectAllStatement = "SELECT * FROM EXPENSE";




var createStatement2 = "CREATE TABLE IF NOT EXISTS INCOME (inc_id INTEGER PRIMARY KEY AUTOINCREMENT, method TEXT, date DATE, recfrom TEXT, amount INTEGER, details TEXT)";

var insertStatement2= "INSERT INTO INCOME (method, date, recfrom, amount) VALUES (?,?,?,?)";
var dropStatement2 = "DROP TABLE INCOME";

var selectAllStatement2 = "SELECT * FROM INCOME";





var db = openDatabase("EXPENSE RECORD", "1.0", "EXP Book", 200000);
var dataset; 
var dataset1,dataset2,dataset3,dataset4,dataset5; 

function initDatabase()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
 
            createTable();  // If supported then call Function for create table in SQLite
            fetchrecord();
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}













var db2 = openDatabase("EXPENSE RECORD", "1.0", "INCOME", 200000);
var dataset22; 
var dataset1,dataset2,dataset3,dataset4,dataset5; 

function initDatabase2()  // Function Call When Page is ready.
 
{
 
    try {
 
        if (!window.openDatabase)  // Check browser is supported SQLite or not.
 
        {
 
            alert('Databases are not supported in this browser.');
 
        }
 
        else 
        {
            
 
            createTable2();  // If supported then call Function for create table in SQLite
            fetchrecord2();
        }
 
    }
 
    catch (e) {
 
        if (e == 2) {

 
            // Version number mismatch. 
 
            console.log("Invalid database version.");
 
        } else {
 
            console.log("Unknown error " + e + ".");
 
        }
 
        return;
 
    }
 
}






















function createTable()  // Function for Create Table in SQLite.
 
{
    
    
    db.transaction(function (tx) { tx.executeSql(createStatement, [],showRecords, onError); });
    alert("created");
    
    checkRecords();

   

    
}










function createTable2()  // Function for Create Table in SQLite.
 
{
    
    
    db.transaction(function (tx) { tx.executeSql(createStatement2, [],showRecords, onError); });
    alert("created income");
    
    checkRecords2();

   

    
}
















function fetchrecord()
{
    var totalexp=0;
   
    
    $("#results").html('')
    
     var tableinit = '<table border=0> ';
    $("#results").append(tableinit);
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement, [], function (tx, result) {
 
            dataset = result.rows;
           
            for (var i = 0, item = null; i < dataset.length; i++) 
            {
 
                item = dataset.item(i);
                
                totalexp = totalexp + item['amount'];
           
              
               
           
                var tableend ='</table>'  
                
                var linkeditdelete = '<tr><td> '+ totalexp +'</td> </tr> ';
                
                
                        
            }
              $("#results").append(linkeditdelete);
                $("#results").append(tableend);
            
            
        });
 
    });
}














function fetchrecord2()
{
    var totalinc=0;
   
    
    $("#results2").html('')
    
     var tableinit2 = '<table border=0> ';
    $("#results2").append(tableinit2);
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement2, [], function (tx, result2) {
 
            dataset22 = result2.rows;
           
            for (var i = 0, item2 = null; i < dataset22.length; i++) 
            {
 
                item2 = dataset22.item(i);
                
                totalinc = totalinc + item2['amount'];
           
              
               
           
                var tableend2 ='</table>'  
                
                var linkeditdelete2 = '<tr><td> '+ totalinc +'</td> </tr> ';
                
                
                        
            }
              $("#results2").append(linkeditdelete2);
                $("#results2").append(tableend2);
            
            
        });
 
    });
}













function checkRecords() // Function For Retrive data from Database Display records as list
 
{
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement, [], function (tx, result) 
                      {
 
            dataset = result.rows;
 
                if(dataset.length==0)
                {
                    insertRecord();
                }
            else
            {
               
            }
 
    });
        });

}











function checkRecords2() // Function For Retrive data from Database Display records as list
 
{
 
    db.transaction(function (tx) {
 
        tx.executeSql(selectAllStatement2, [], function (tx, result2) 
                      {
 
            dataset22 = result2.rows;
 
                if(dataset22.length==0)
                {
                    insertRecord2();
                }
            else
            {
               
            }
 
    });
        });

}










                   

function dropFunction()
{
    db.transaction(function (tx) { tx.executeSql(dropStatement, [], showRecords, onError); });   
    alert("tables dropped");
}






function dropFunction2()
{
    db.transaction(function (tx) { tx.executeSql(dropStatement2, [], showRecords, onError); });   
    alert(" income tables dropped");
}











function insertRecord()
{
    
    db.transaction(function (tx) { tx.executeSql(insertStatement,["cash", '03/04/2019', "food" , 200], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertStatement,["cash", '23/04/2019', "food" , 500], loadAndReset, onError); });
     alert("insERTED");
    

    
}












function insertRecord2()
{
    
    db.transaction(function (tx) { tx.executeSql(insertStatement2,["cash", '03/04/2019', "food" , 200], loadAndReset, onError); });
    db.transaction(function (tx) { tx.executeSql(insertStatement2,["cash", '23/04/2019', "food" , 500], loadAndReset, onError); });
     alert("insERTED in income");
    

    
}











function loadAndReset() //Function for Load and Reset...
 
{
 
    
 
    showRecords()
 
}
 
function onError(tx, error) // Function for Hendeling Error...
 
{
 
    alert(error.message);
 
}


function showRecords()
{
     
}

function addFunction()
{
    window.location.href="addexpense.html";
}


function addFunction2()
{
    window.location.href="addincome.html";
}

$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
  
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase();
 

     $("#addexpButton").click(addFunction);
 $("#findButton").click(dropFunction);
});











$(document).ready(function () // Call function when page is ready for load..
 
{
;
 
  
    $("body").fadeIn(2000); // Fede In Effect when Page Load..
 
    initDatabase2();
 

     $("#addincButton").click(addFunction2);
 $("#findButton").click(dropFunction2);
});

















